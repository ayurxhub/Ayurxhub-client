"use client";

import { useState, useEffect } from "react";
import { useAuth } from "../../context/AuthContext";

const SUBJECTS = [
    "Dravyaguna", "Kayachikitsa", "Panchakarma", "Shalya Tantra",
    "Rasayana", "Anatomy", "Pharmacology", "Diagnosis",
    "Prasuti Tantra", "Kaumarabhritya", "General Ayurveda",
];

const DIFFICULTIES = ["easy", "medium", "hard"];

export default function AdminTestsPage() {
    const { authAxios } = useAuth();
    const [tab, setTab] = useState("tests"); // tests | questions
    const [tests, setTests] = useState([]);
    const [questions, setQuestions] = useState([]);
    const [loading, setLoading] = useState(true);

    // Modals
    const [showTestForm, setShowTestForm] = useState(false);
    const [showQForm, setShowQForm] = useState(false);
    const [editingTest, setEditingTest] = useState(null);
    const [editingQ, setEditingQ] = useState(null);

    // Filters
    const [qFilter, setQFilter] = useState({ subject: "", approved: "" });

    useEffect(() => { loadAll(); }, [tab]);

    const loadAll = async () => {
        setLoading(true);
        try {
            if (tab === "tests") {
                const res = await authAxios.get("/tests/admin");
                setTests(res.data.tests || []);
            } else {
                const params = new URLSearchParams();
                if (qFilter.subject) params.append("subject", qFilter.subject);
                if (qFilter.approved !== "") params.append("approved", qFilter.approved);
                params.append("limit", "100");
                const res = await authAxios.get(`/tests/questions?${params}`);
                setQuestions(res.data.questions || []);
            }
        } catch (e) { console.error(e); }
        finally { setLoading(false); }
    };

    const togglePublish = async (id) => {
        await authAxios.put(`/tests/${id}/publish`);
        loadAll();
    };

    const deleteTest = async (id) => {
        if (!confirm("Delete this test?")) return;
        await authAxios.delete(`/tests/${id}`);
        loadAll();
    };

    const approveQ = async (id) => {
        await authAxios.put(`/tests/questions/${id}/approve`);
        loadAll();
    };

    const deleteQ = async (id) => {
        if (!confirm("Delete this question?")) return;
        await authAxios.delete(`/tests/questions/${id}`);
        loadAll();
    };

    return (
        <div>
            {/* Header */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
                <div>
                    <h1 style={{ fontSize: 20, fontWeight: 500, color: "#ffffff", margin: "0 0 4px" }}>Test Series</h1>
                    <p style={{ fontSize: 13, color: "#4a5568", margin: 0 }}>Manage tests and question bank</p>
                </div>
                <button
                    onClick={() => { tab === "tests" ? setShowTestForm(true) : setShowQForm(true); setEditingTest(null); setEditingQ(null); }}
                    style={{ padding: "9px 20px", borderRadius: 10, border: "none", background: "#1D9E75", color: "#fff", fontSize: 13, fontWeight: 600, cursor: "pointer", fontFamily: "inherit" }}>
                    + {tab === "tests" ? "New Test" : "Add Question"}
                </button>
            </div>

            {/* Tabs */}
            <div style={{ display: "flex", gap: 4, background: "#161b27", borderRadius: 10, padding: 4, width: "fit-content", marginBottom: 20 }}>
                {["tests", "questions"].map(t => (
                    <button key={t} onClick={() => setTab(t)} style={{ padding: "7px 18px", borderRadius: 8, border: "none", cursor: "pointer", fontFamily: "inherit", fontSize: 12, fontWeight: 500, textTransform: "capitalize", background: tab === t ? "#1D9E75" : "transparent", color: tab === t ? "#fff" : "#6b7280", transition: "all 0.15s" }}>
                        {t === "tests" ? "📋 Tests" : "❓ Questions"}
                    </button>
                ))}
            </div>

            {/* Question filters */}
            {tab === "questions" && (
                <div style={{ display: "flex", gap: 10, marginBottom: 16, flexWrap: "wrap" }}>
                    <select value={qFilter.subject} onChange={e => setQFilter(f => ({ ...f, subject: e.target.value }))} onBlur={loadAll}
                        style={{ padding: "7px 12px", borderRadius: 8, border: "0.5px solid rgba(255,255,255,0.1)", background: "#161b27", color: "#fff", fontSize: 12, fontFamily: "inherit", cursor: "pointer" }}>
                        <option value="">All Subjects</option>
                        {SUBJECTS.map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                    <select value={qFilter.approved} onChange={e => { setQFilter(f => ({ ...f, approved: e.target.value })); setTimeout(loadAll, 0); }}
                        style={{ padding: "7px 12px", borderRadius: 8, border: "0.5px solid rgba(255,255,255,0.1)", background: "#161b27", color: "#fff", fontSize: 12, fontFamily: "inherit", cursor: "pointer" }}>
                        <option value="">All Status</option>
                        <option value="true">Approved</option>
                        <option value="false">Pending</option>
                    </select>
                    <button onClick={loadAll} style={{ padding: "7px 14px", borderRadius: 8, border: "none", background: "#1D9E75", color: "#fff", fontSize: 12, cursor: "pointer", fontFamily: "inherit" }}>Apply</button>
                </div>
            )}

            {/* Content */}
            {loading ? (
                <div style={{ display: "flex", justifyContent: "center", padding: 60 }}>
                    <div style={{ width: 28, height: 28, borderRadius: "50%", border: "3px solid #1D9E75", borderTopColor: "transparent", animation: "spin 0.8s linear infinite" }} />
                </div>
            ) : tab === "tests" ? (
                <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                    {tests.length === 0 && <p style={{ color: "#4a5568", textAlign: "center", padding: 40 }}>No tests yet. Create one above.</p>}
                    {tests.map(test => (
                        <div key={test._id} style={{ background: "#161b27", border: "0.5px solid rgba(255,255,255,0.06)", borderRadius: 12, padding: "16px 20px", display: "flex", alignItems: "center", gap: 16 }}>
                            <div style={{ width: 40, height: 40, borderRadius: 10, background: test.type === "free" ? "rgba(29,158,117,0.15)" : "rgba(59,130,246,0.15)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, flexShrink: 0 }}>
                                {test.type === "free" ? "🆓" : "⭐"}
                            </div>
                            <div style={{ flex: 1, minWidth: 0 }}>
                                <p style={{ fontSize: 14, fontWeight: 500, color: "#fff", margin: "0 0 3px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{test.title}</p>
                                <div style={{ display: "flex", gap: 10 }}>
                                    <span style={{ fontSize: 11, color: "#4a5568" }}>{test.subject}</span>
                                    <span style={{ fontSize: 11, color: "#4a5568" }}>·</span>
                                    <span style={{ fontSize: 11, color: "#4a5568" }}>{test.totalQuestions} Qs</span>
                                    <span style={{ fontSize: 11, color: "#4a5568" }}>·</span>
                                    <span style={{ fontSize: 11, color: "#4a5568" }}>{test.duration} min</span>
                                    <span style={{ fontSize: 11, color: "#4a5568" }}>·</span>
                                    <span style={{ fontSize: 11, color: "#4a5568" }}>{test.attempts || 0} attempts</span>
                                </div>
                            </div>
                            <div style={{ display: "flex", gap: 8, alignItems: "center", flexShrink: 0 }}>
                                <span style={{ fontSize: 10, fontWeight: 700, padding: "3px 9px", borderRadius: 20, background: test.isPublished ? "rgba(29,158,117,0.2)" : "rgba(74,85,104,0.3)", color: test.isPublished ? "#1D9E75" : "#718096" }}>
                                    {test.isPublished ? "Published" : "Draft"}
                                </span>
                                <button onClick={() => togglePublish(test._id)} style={{ padding: "5px 12px", borderRadius: 7, border: "0.5px solid rgba(255,255,255,0.1)", background: "transparent", color: "#9ca3af", fontSize: 11, cursor: "pointer", fontFamily: "inherit" }}>
                                    {test.isPublished ? "Unpublish" : "Publish"}
                                </button>
                                <button onClick={() => { setEditingTest(test); setShowTestForm(true); }} style={{ padding: "5px 12px", borderRadius: 7, border: "0.5px solid rgba(255,255,255,0.1)", background: "transparent", color: "#9ca3af", fontSize: 11, cursor: "pointer", fontFamily: "inherit" }}>
                                    Edit
                                </button>
                                <button onClick={() => deleteTest(test._id)} style={{ padding: "5px 12px", borderRadius: 7, border: "0.5px solid rgba(239,68,68,0.3)", background: "transparent", color: "#ef4444", fontSize: 11, cursor: "pointer", fontFamily: "inherit" }}>
                                    Delete
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            ) : (
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                    {questions.length === 0 && <p style={{ color: "#4a5568", textAlign: "center", padding: 40 }}>No questions found.</p>}
                    {questions.map((q, i) => (
                        <div key={q._id} style={{ background: "#161b27", border: "0.5px solid rgba(255,255,255,0.06)", borderRadius: 10, padding: "14px 18px" }}>
                            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12 }}>
                                <div style={{ flex: 1 }}>
                                    <p style={{ fontSize: 13, color: "#fff", margin: "0 0 6px", lineHeight: 1.5 }}>{i + 1}. {q.text}</p>
                                    <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                                        <span style={{ fontSize: 10, padding: "2px 8px", borderRadius: 20, background: "rgba(29,158,117,0.15)", color: "#1D9E75" }}>{q.subject}</span>
                                        <span style={{ fontSize: 10, padding: "2px 8px", borderRadius: 20, background: q.difficulty === "hard" ? "rgba(239,68,68,0.15)" : q.difficulty === "easy" ? "rgba(29,158,117,0.15)" : "rgba(234,179,8,0.15)", color: q.difficulty === "hard" ? "#ef4444" : q.difficulty === "easy" ? "#1D9E75" : "#ca8a04" }}>{q.difficulty}</span>
                                        <span style={{ fontSize: 10, padding: "2px 8px", borderRadius: 20, background: q.isApproved ? "rgba(29,158,117,0.15)" : "rgba(234,179,8,0.15)", color: q.isApproved ? "#1D9E75" : "#ca8a04" }}>
                                            {q.isApproved ? "✓ Approved" : "⏳ Pending"}
                                        </span>
                                        <span style={{ fontSize: 10, color: "#4a5568" }}>by {q.createdBy?.name}</span>
                                    </div>
                                </div>
                                <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
                                    {!q.isApproved && (
                                        <button onClick={() => approveQ(q._id)} style={{ padding: "5px 10px", borderRadius: 6, border: "none", background: "#1D9E75", color: "#fff", fontSize: 11, cursor: "pointer", fontFamily: "inherit" }}>Approve</button>
                                    )}
                                    <button onClick={() => { setEditingQ(q); setShowQForm(true); }} style={{ padding: "5px 10px", borderRadius: 6, border: "0.5px solid rgba(255,255,255,0.1)", background: "transparent", color: "#9ca3af", fontSize: 11, cursor: "pointer", fontFamily: "inherit" }}>Edit</button>
                                    <button onClick={() => deleteQ(q._id)} style={{ padding: "5px 10px", borderRadius: 6, border: "0.5px solid rgba(239,68,68,0.3)", background: "transparent", color: "#ef4444", fontSize: 11, cursor: "pointer", fontFamily: "inherit" }}>Del</button>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            )}

            {/* Test Form Modal */}
            {showTestForm && <TestFormModal authAxios={authAxios} editing={editingTest} onClose={() => setShowTestForm(false)} onSaved={loadAll} />}

            {/* Question Form Modal */}
            {showQForm && <QuestionFormModal authAxios={authAxios} editing={editingQ} onClose={() => setShowQForm(false)} onSaved={loadAll} />}

            <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        </div>
    );
}

// ── Test Form Modal ───────────────────────────────────────────────────────────
function TestFormModal({ authAxios, editing, onClose, onSaved }) {
    const [form, setForm] = useState({
        title: editing?.title || "",
        description: editing?.description || "",
        subject: editing?.subject || SUBJECTS[0],
        type: editing?.type || "free",
        price: editing?.price || 0,
        duration: editing?.duration || 30,
        passingScore: editing?.passingScore || 60,
        shuffleQuestions: editing?.shuffleQuestions || false,
        questionIds: "",
    });
    const [saving, setSaving] = useState(false);

    const handleSave = async () => {
        setSaving(true);
        try {
            const payload = {
                ...form,
                questionIds: form.questionIds.split(",").map(s => s.trim()).filter(Boolean),
            };
            if (editing) await authAxios.put(`/tests/${editing._id}`, { ...payload, questionIds: payload.questionIds });
            else await authAxios.post("/tests", payload);
            onSaved();
            onClose();
        } catch (e) { alert(e.response?.data?.message || "Save failed"); }
        finally { setSaving(false); }
    };

    return (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.6)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 100, padding: 20 }}>
            <div style={{ background: "#161b27", borderRadius: 16, padding: 28, width: "100%", maxWidth: 520, border: "0.5px solid rgba(255,255,255,0.1)", maxHeight: "90vh", overflowY: "auto" }}>
                <h2 style={{ fontSize: 16, fontWeight: 600, color: "#fff", margin: "0 0 20px" }}>{editing ? "Edit Test" : "Create Test"}</h2>

                <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                    {[["Title", "title", "text"], ["Description", "description", "text"], ["Duration (minutes)", "duration", "number"], ["Passing Score (%)", "passingScore", "number"], ["Price (₹)", "price", "number"]].map(([label, key, type]) => (
                        <div key={key}>
                            <label style={lbl}>{label}</label>
                            <input type={type} value={form[key]} onChange={e => setForm(f => ({ ...f, [key]: type === "number" ? Number(e.target.value) : e.target.value }))} style={inp} />
                        </div>
                    ))}

                    <div><label style={lbl}>Subject</label>
                        <select value={form.subject} onChange={e => setForm(f => ({ ...f, subject: e.target.value }))} style={inp}>
                            {SUBJECTS.map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                    </div>

                    <div><label style={lbl}>Type</label>
                        <select value={form.type} onChange={e => setForm(f => ({ ...f, type: e.target.value }))} style={inp}>
                            <option value="free">Free (5 questions, fixed)</option>
                            <option value="paid">Paid (50–100 questions)</option>
                        </select>
                    </div>

                    <div>
                        <label style={lbl}>Question IDs (comma-separated MongoDB IDs)</label>
                        <textarea value={form.questionIds} onChange={e => setForm(f => ({ ...f, questionIds: e.target.value }))} rows={3} placeholder="64abc..., 64def..., ..." style={{ ...inp, resize: "vertical" }} />
                        <p style={{ fontSize: 11, color: "#4a5568", margin: "4px 0 0" }}>Copy IDs from the Questions tab</p>
                    </div>

                    <label style={{ display: "flex", alignItems: "center", gap: 10, cursor: "pointer" }}>
                        <input type="checkbox" checked={form.shuffleQuestions} onChange={e => setForm(f => ({ ...f, shuffleQuestions: e.target.checked }))} />
                        <span style={{ fontSize: 13, color: "#9ca3af" }}>Shuffle question order</span>
                    </label>
                </div>

                <div style={{ display: "flex", gap: 10, marginTop: 22 }}>
                    <button onClick={onClose} style={{ flex: 1, padding: "10px", borderRadius: 8, border: "0.5px solid rgba(255,255,255,0.1)", background: "transparent", color: "#9ca3af", cursor: "pointer", fontFamily: "inherit" }}>Cancel</button>
                    <button onClick={handleSave} disabled={saving} style={{ flex: 2, padding: "10px", borderRadius: 8, border: "none", background: "#1D9E75", color: "#fff", fontWeight: 600, cursor: "pointer", fontFamily: "inherit" }}>
                        {saving ? "Saving…" : editing ? "Save Changes" : "Create Test"}
                    </button>
                </div>
            </div>
        </div>
    );
}

// ── Question Form Modal ───────────────────────────────────────────────────────
function QuestionFormModal({ authAxios, editing, onClose, onSaved }) {
    const [form, setForm] = useState({
        text: editing?.text || "",
        options: editing?.options || ["", "", "", ""],
        correctIndex: editing?.correctIndex ?? 0,
        explanation: editing?.explanation || "",
        subject: editing?.subject || SUBJECTS[0],
        difficulty: editing?.difficulty || "medium",
        tags: editing?.tags?.join(", ") || "",
    });
    const [saving, setSaving] = useState(false);

    const handleSave = async () => {
        if (!form.text || form.options.some(o => !o.trim())) { alert("Fill all fields and options"); return; }
        setSaving(true);
        try {
            const payload = { ...form, tags: form.tags.split(",").map(t => t.trim()).filter(Boolean) };
            if (editing) await authAxios.put(`/tests/questions/${editing._id}`, payload);
            else await authAxios.post("/tests/questions", payload);
            onSaved();
            onClose();
        } catch (e) { alert(e.response?.data?.message || "Save failed"); }
        finally { setSaving(false); }
    };

    return (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.6)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 100, padding: 20 }}>
            <div style={{ background: "#161b27", borderRadius: 16, padding: 28, width: "100%", maxWidth: 560, border: "0.5px solid rgba(255,255,255,0.1)", maxHeight: "90vh", overflowY: "auto" }}>
                <h2 style={{ fontSize: 16, fontWeight: 600, color: "#fff", margin: "0 0 20px" }}>{editing ? "Edit Question" : "Add Question"}</h2>

                <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                    <div>
                        <label style={lbl}>Question Text</label>
                        <textarea value={form.text} onChange={e => setForm(f => ({ ...f, text: e.target.value }))} rows={3} style={{ ...inp, resize: "vertical" }} placeholder="Enter the question…" />
                    </div>

                    <div>
                        <label style={lbl}>Options (mark correct with the radio)</label>
                        {form.options.map((opt, i) => (
                            <div key={i} style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 8 }}>
                                <input type="radio" name="correct" checked={form.correctIndex === i} onChange={() => setForm(f => ({ ...f, correctIndex: i }))} />
                                <span style={{ fontSize: 12, color: "#9ca3af", width: 16 }}>{["A", "B", "C", "D"][i]}</span>
                                <input value={opt} onChange={e => { const o = [...form.options]; o[i] = e.target.value; setForm(f => ({ ...f, options: o })); }} style={{ ...inp, flex: 1, margin: 0 }} placeholder={`Option ${["A", "B", "C", "D"][i]}`} />
                                {form.correctIndex === i && <span style={{ fontSize: 11, color: "#1D9E75", fontWeight: 700 }}>✓ Correct</span>}
                            </div>
                        ))}
                    </div>

                    <div>
                        <label style={lbl}>Explanation (shown after submission)</label>
                        <textarea value={form.explanation} onChange={e => setForm(f => ({ ...f, explanation: e.target.value }))} rows={2} style={{ ...inp, resize: "vertical" }} placeholder="Why is the answer correct?" />
                    </div>

                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                        <div><label style={lbl}>Subject</label>
                            <select value={form.subject} onChange={e => setForm(f => ({ ...f, subject: e.target.value }))} style={inp}>
                                {SUBJECTS.map(s => <option key={s} value={s}>{s}</option>)}
                            </select>
                        </div>
                        <div><label style={lbl}>Difficulty</label>
                            <select value={form.difficulty} onChange={e => setForm(f => ({ ...f, difficulty: e.target.value }))} style={inp}>
                                {DIFFICULTIES.map(d => <option key={d} value={d}>{d}</option>)}
                            </select>
                        </div>
                    </div>

                    <div><label style={lbl}>Tags (comma-separated)</label>
                        <input value={form.tags} onChange={e => setForm(f => ({ ...f, tags: e.target.value }))} style={inp} placeholder="vata, herbs, classic…" />
                    </div>
                </div>

                <div style={{ display: "flex", gap: 10, marginTop: 22 }}>
                    <button onClick={onClose} style={{ flex: 1, padding: "10px", borderRadius: 8, border: "0.5px solid rgba(255,255,255,0.1)", background: "transparent", color: "#9ca3af", cursor: "pointer", fontFamily: "inherit" }}>Cancel</button>
                    <button onClick={handleSave} disabled={saving} style={{ flex: 2, padding: "10px", borderRadius: 8, border: "none", background: "#1D9E75", color: "#fff", fontWeight: 600, cursor: "pointer", fontFamily: "inherit" }}>
                        {saving ? "Saving…" : editing ? "Save Changes" : "Add Question"}
                    </button>
                </div>
            </div>
        </div>
    );
}

const lbl = { display: "block", fontSize: 11, fontWeight: 600, color: "#9ca3af", marginBottom: 5, textTransform: "uppercase", letterSpacing: "0.05em" };
const inp = { width: "100%", padding: "9px 12px", borderRadius: 8, border: "0.5px solid rgba(255,255,255,0.1)", background: "#0f1117", color: "#fff", fontSize: 13, outline: "none", boxSizing: "border-box", fontFamily: "inherit" };