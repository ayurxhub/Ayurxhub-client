"use client";

import { useState, useEffect } from "react";
import { useAuth } from "../context/AuthContext";
import { useRouter } from "next/navigation";
import ProtectedRoute from "../components/ProtectedRoute";

const SUBJECTS = [
  { name: "Dravyaguna", icon: "🌿", color: { bg: "#E1F5EE", text: "#0F6E56", border: "#9FE1CB" } },
  { name: "Kayachikitsa", icon: "🩺", color: { bg: "#dbe1ff", text: "#00256e", border: "#A8B4FF" } },
  { name: "Panchakarma", icon: "💧", color: { bg: "#E8F4FF", text: "#0057A8", border: "#93C5FD" } },
  { name: "Shalya Tantra", icon: "⚕️", color: { bg: "#ffd9e5", text: "#5a0034", border: "#FFB3CA" } },
  { name: "Rasayana", icon: "✨", color: { bg: "#FFF3CD", text: "#7A4F00", border: "#FFD970" } },
  { name: "Anatomy", icon: "🦴", color: { bg: "#F2E8FF", text: "#4A007A", border: "#D4AAFF" } },
  { name: "Pharmacology", icon: "💊", color: { bg: "#FFF0E0", text: "#8B4513", border: "#FFD0A0" } },
  { name: "Diagnosis", icon: "🔬", color: { bg: "#E8F8F0", text: "#1A6B3C", border: "#86EFB0" } },
  { name: "Prasuti Tantra", icon: "🌸", color: { bg: "#FFE4F0", text: "#9B1060", border: "#FFB0D8" } },
  { name: "Kaumarabhritya", icon: "👶", color: { bg: "#E4F0FF", text: "#1060A0", border: "#B0D0FF" } },
  { name: "General Ayurveda", icon: "📖", color: { bg: "#F5F0FF", text: "#5000C8", border: "#C8A8FF" } },
];

export default function TestsPage() {
  return <ProtectedRoute><TestListing /></ProtectedRoute>;
}

// ── Chapterwise banner — defined OUTSIDE TestListing ─────────────────────────
function ChapterwiseBanner({ onNavigate }) {
  return (
    <div
      onClick={onNavigate}
      style={{
        background: "linear-gradient(135deg, #00256e 0%, #0a3d8f 55%, #0e4f3b 100%)",
        borderRadius: 16,
        padding: "20px 24px",
        marginBottom: 24,
        cursor: "pointer",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: 16,
        boxShadow: "0 4px 20px rgba(0,37,110,0.2)",
        transition: "transform 0.15s, box-shadow 0.15s",
      }}
      onMouseEnter={e => {
        e.currentTarget.style.transform = "translateY(-2px)";
        e.currentTarget.style.boxShadow = "0 8px 28px rgba(0,37,110,0.28)";
      }}
      onMouseLeave={e => {
        e.currentTarget.style.transform = "translateY(0)";
        e.currentTarget.style.boxShadow = "0 4px 20px rgba(0,37,110,0.2)";
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
        <div style={{ fontSize: 36 }}>🌿</div>
        <div>
          <p style={{ fontSize: 15, fontWeight: 700, color: "#fff", margin: "0 0 3px" }}>
            Swasthavritta evam Yoga
          </p>
          <p style={{ fontSize: 12, color: "rgba(255,255,255,0.6)", margin: 0 }}>
            Chapter-wise tests · Term 1 &amp; Term 2 · 8 chapters available
          </p>
        </div>
      </div>
      <div style={{
        background: "rgba(255,255,255,0.12)",
        border: "1px solid rgba(255,255,255,0.2)",
        borderRadius: 10,
        padding: "8px 18px",
        color: "#fff",
        fontSize: 13,
        fontWeight: 600,
        whiteSpace: "nowrap",
        backdropFilter: "blur(8px)",
      }}>
        View Chapters →
      </div>
    </div>
  );
}

function TestListing() {
  const { authAxios } = useAuth();
  const router = useRouter();
  const [bySubject, setBySubject] = useState({});
  const [attempts, setAttempts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeSubject, setActiveSubject] = useState(null);
  const [search, setSearch] = useState("");

  useEffect(() => {
    const load = async () => {
      try {
        const [testsRes, attemptsRes] = await Promise.all([
          authAxios.get("/tests"),
          authAxios.get("/tests/my-attempts"),
        ]);
        setBySubject(testsRes.data.bySubject || {});
        setAttempts(attemptsRes.data.attempts || []);
      } catch (e) { console.error(e); }
      finally { setLoading(false); }
    };
    load();
  }, []);

  const attemptMap = {};
  attempts.forEach(a => {
    const tid = a.test?._id;
    if (!tid) return;
    if (!attemptMap[tid] || a.percentage > attemptMap[tid].percentage) attemptMap[tid] = a;
  });

  const filteredSubjects = SUBJECTS.filter(s =>
    !search || s.name.toLowerCase().includes(search.toLowerCase())
  );

  const activeData = activeSubject ? (bySubject[activeSubject] || { free: [], paid: [] }) : null;
  const activeMeta = SUBJECTS.find(s => s.name === activeSubject);

  return (
    <div style={{ minHeight: "100vh", background: "#f7f9fc" }}>
      <div style={{ padding: "28px 32px", maxWidth: 1100 }}>

        <div style={{ marginBottom: 24 }}>
          <h1 style={{ fontSize: 22, fontWeight: 700, color: "#00256e", margin: "0 0 4px" }}>Test Series</h1>
          <p style={{ fontSize: 14, color: "#757682", margin: 0 }}>Subject-wise MCQ tests — 5 free questions per test, premium tests with 50–100 questions</p>
        </div>

        {/* Stats */}
        <div style={{ display: "flex", gap: 12, marginBottom: 28 }}>
          {[
            { label: "Attempted", value: attempts.length, icon: "📝" },
            { label: "Avg Score", value: attempts.length ? `${Math.round(attempts.reduce((s, a) => s + a.percentage, 0) / attempts.length)}%` : "—", icon: "📊" },
            { label: "Passed", value: attempts.filter(a => a.passed).length, icon: "✅" },
          ].map(({ label, value, icon }) => (
            <div key={label} style={{ background: "#fff", borderRadius: 12, padding: "14px 20px", border: "0.5px solid rgba(197,198,211,0.35)", flex: 1 }}>
              <p style={{ fontSize: 11, color: "#9ca3af", textTransform: "uppercase", letterSpacing: "0.06em", margin: "0 0 4px" }}>{icon} {label}</p>
              <p style={{ fontSize: 24, fontWeight: 700, color: "#00256e", margin: 0 }}>{value}</p>
            </div>
          ))}
        </div>

        {/* Chapterwise banner */}
        <ChapterwiseBanner onNavigate={() => router.push("/tests/chapterwise")} />

        <div style={{ display: "flex", gap: 24 }}>
          {/* Sidebar */}
          <div style={{ width: 220, flexShrink: 0 }}>
            <input
              placeholder="Search subject…"
              value={search}
              onChange={e => setSearch(e.target.value)}
              style={{ width: "100%", padding: "8px 12px", borderRadius: 10, marginBottom: 10, border: "0.5px solid rgba(197,198,211,0.5)", background: "#fff", fontSize: 13, outline: "none", boxSizing: "border-box", fontFamily: "inherit" }}
            />
            <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
              {filteredSubjects.map(s => {
                const data = bySubject[s.name] || { free: [], paid: [] };
                const total = data.free.length + data.paid.length;
                const isActive = activeSubject === s.name;
                return (
                  <button key={s.name} onClick={() => setActiveSubject(isActive ? null : s.name)}
                    style={{
                      display: "flex", alignItems: "center", gap: 10, padding: "10px 12px",
                      borderRadius: 10, border: "none", cursor: "pointer", fontFamily: "inherit", textAlign: "left",
                      background: isActive ? s.color.bg : "#fff",
                      borderLeft: `3px solid ${isActive ? s.color.text : "transparent"}`,
                      transition: "all 0.15s",
                    }}>
                    <span style={{ fontSize: 15 }}>{s.icon}</span>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <p style={{ fontSize: 12, fontWeight: 600, color: isActive ? s.color.text : "#374151", margin: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{s.name}</p>
                      {total > 0 && <p style={{ fontSize: 10, color: "#9ca3af", margin: 0 }}>{data.free.length} free · {data.paid.length} paid</p>}
                    </div>
                    {total > 0 && <span style={{ fontSize: 10, fontWeight: 700, padding: "2px 6px", borderRadius: 20, background: isActive ? s.color.text : "#f3f4f6", color: isActive ? "#fff" : "#6b7280" }}>{total}</span>}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Main */}
          <div style={{ flex: 1 }}>
            {loading ? (
              <div style={{ display: "flex", justifyContent: "center", padding: 80 }}>
                <div style={{ width: 32, height: 32, borderRadius: "50%", border: "3px solid #00256e", borderTopColor: "transparent", animation: "spin 0.8s linear infinite" }} />
              </div>
            ) : !activeSubject ? (
              <>
                <p style={{ fontSize: 13, color: "#9ca3af", marginBottom: 16 }}>← Select a subject to see available tests</p>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(155px, 1fr))", gap: 12 }}>
                  {filteredSubjects.map(s => {
                    const data = bySubject[s.name] || { free: [], paid: [] };
                    const total = data.free.length + data.paid.length;
                    return (
                      <button key={s.name} onClick={() => setActiveSubject(s.name)}
                        style={{ padding: "20px 16px", borderRadius: 14, border: `1px solid ${s.color.border}`, background: s.color.bg, cursor: "pointer", textAlign: "center", fontFamily: "inherit", transition: "all 0.15s" }}
                        onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-3px)"; e.currentTarget.style.boxShadow = "0 8px 24px rgba(0,0,0,0.1)"; }}
                        onMouseLeave={e => { e.currentTarget.style.transform = "translateY(0)"; e.currentTarget.style.boxShadow = "none"; }}>
                        <p style={{ fontSize: 28, margin: "0 0 8px" }}>{s.icon}</p>
                        <p style={{ fontSize: 12, fontWeight: 600, color: s.color.text, margin: "0 0 3px" }}>{s.name}</p>
                        <p style={{ fontSize: 10, color: s.color.text, opacity: 0.7, margin: 0 }}>{total > 0 ? `${data.free.length} free · ${data.paid.length} paid` : "Coming soon"}</p>
                      </button>
                    );
                  })}
                </div>
              </>
            ) : (
              <>
                <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
                  <button onClick={() => setActiveSubject(null)} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 18, color: "#6b7280", padding: "4px 8px" }}>←</button>
                  <span style={{ fontSize: 20 }}>{activeMeta?.icon}</span>
                  <h2 style={{ fontSize: 18, fontWeight: 700, color: "#111827", margin: 0 }}>{activeSubject}</h2>
                </div>

                {(activeData.free.length === 0 && activeData.paid.length === 0) ? (
                  <div style={{ textAlign: "center", padding: 60, background: "#fff", borderRadius: 14, border: "0.5px solid rgba(197,198,211,0.35)" }}>
                    <p style={{ fontSize: 32, margin: "0 0 8px" }}>📭</p>
                    <p style={{ fontSize: 14, color: "#6b7280" }}>No tests published yet for this subject</p>
                  </div>
                ) : (
                  <div style={{ display: "flex", flexDirection: "column", gap: 28 }}>
                    {activeData.free.length > 0 && (
                      <div>
                        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
                          <span style={{ fontSize: 14, fontWeight: 700, color: "#166534" }}>🆓 Free Tests</span>
                          <span style={{ fontSize: 11, padding: "2px 8px", borderRadius: 20, background: "#dcfce7", color: "#166534" }}>{activeData.free.length} tests</span>
                          <span style={{ fontSize: 11, color: "#9ca3af" }}>· Same questions every time · 5 per test</span>
                        </div>
                        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                          {activeData.free.map(test => <TestCard key={test._id} test={test} attempt={attemptMap[test._id]} onStart={() => router.push(`/tests/${test._id}`)} />)}
                        </div>
                      </div>
                    )}
                    {activeData.paid.length > 0 && (
                      <div>
                        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
                          <span style={{ fontSize: 14, fontWeight: 700, color: "#1e40af" }}>⭐ Premium Tests</span>
                          <span style={{ fontSize: 11, padding: "2px 8px", borderRadius: 20, background: "#dbeafe", color: "#1e40af" }}>{activeData.paid.length} tests</span>
                          <span style={{ fontSize: 11, color: "#9ca3af" }}>· 50–100 questions · Questions shuffled</span>
                        </div>
                        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                          {activeData.paid.map(test => <TestCard key={test._id} test={test} attempt={attemptMap[test._id]} onStart={() => router.push(`/tests/${test._id}`)} />)}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

function TestCard({ test, attempt, onStart }) {
  const isFree = test.type === "free";
  return (
    <div style={{ background: "#fff", borderRadius: 14, padding: "18px 20px", border: `1px solid ${isFree ? "rgba(134,239,172,0.4)" : "rgba(147,197,253,0.4)"}`, boxShadow: "0 1px 6px rgba(0,0,0,0.04)", display: "flex", alignItems: "center", gap: 16 }}>
      <div style={{ width: 46, height: 46, borderRadius: 12, flexShrink: 0, background: isFree ? "#dcfce7" : "#dbeafe", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20 }}>
        {isFree ? "🆓" : "⭐"}
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <p style={{ fontSize: 14, fontWeight: 600, color: "#111827", margin: "0 0 5px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{test.title}</p>
        <div style={{ display: "flex", gap: 12, flexWrap: "wrap", alignItems: "center" }}>
          <span style={{ fontSize: 11, color: "#6b7280" }}>⏱ {test.duration} min</span>
          <span style={{ fontSize: 11, color: "#6b7280" }}>📝 {test.totalQuestions} questions</span>
          <span style={{ fontSize: 11, color: "#6b7280" }}>🎯 Pass: {test.passingScore}%</span>
          {attempt && (
            <span style={{ fontSize: 11, fontWeight: 600, padding: "1px 8px", borderRadius: 20, background: attempt.passed ? "#dcfce7" : "#fee2e2", color: attempt.passed ? "#166534" : "#dc2626" }}>
              Best: {attempt.percentage}% {attempt.passed ? "✓" : "✗"}
            </span>
          )}
        </div>
        {test.description && <p style={{ fontSize: 11, color: "#9ca3af", margin: "4px 0 0", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{test.description}</p>}
      </div>
      <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 5, flexShrink: 0 }}>
        {!isFree && test.price > 0 && <span style={{ fontSize: 13, fontWeight: 700, color: "#1e40af" }}>₹{test.price}</span>}
        <button onClick={onStart} style={{ padding: "8px 20px", borderRadius: 10, border: "none", cursor: "pointer", fontFamily: "inherit", fontSize: 13, fontWeight: 600, background: isFree ? "linear-gradient(135deg, #0e4f3b, #1D9E75)" : "linear-gradient(135deg, #1e40af, #3b82f6)", color: "#fff", boxShadow: isFree ? "0 2px 8px rgba(29,158,117,0.3)" : "0 2px 8px rgba(59,130,246,0.3)", whiteSpace: "nowrap" }}>
          {attempt ? "Retake" : "Start"} →
        </button>
      </div>
    </div>
  );
}